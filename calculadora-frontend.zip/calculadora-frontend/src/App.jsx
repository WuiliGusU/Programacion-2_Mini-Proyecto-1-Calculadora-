import React, { useState } from 'react';

function App() {
  const [operacion, setOperacion] = useState('sumar');
  const [a, setA] = useState('');
  const [b, setB] = useState('');
  const [resultado, setResultado] = useState(null);

  const calcular = async () => {
    try {
      const response = await fetch(`http://localhost:8080/api/${operacion}?a=${a}&b=${b}`);
      const data = await response.json();
      setResultado(data);
    } catch (error) {
      console.error('Error al realizar la operación:', error);
    }
  };

  return (
    <div>
      <h1>Calculadora</h1>
      <input type="number" value={a} onChange={(e) => setA(e.target.value)} placeholder="Número A" />
      <input type="number" value={b} onChange={(e) => setB(e.target.value)} placeholder="Número B" />
      <select value={operacion} onChange={(e) => setOperacion(e.target.value)}>
        <option value="sumar">Sumar</option>
        <option value="restar">Restar</option>
        <option value="multiplicar">Multiplicar</option>
        <option value="dividir">Dividir</option>
      </select>
      <button onClick={calcular}>Calcular</button>
      {resultado !== null && <h2>Resultado: {resultado}</h2>}
    </div>
  );
}

export default App;
